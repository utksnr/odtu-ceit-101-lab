import random

n = ["Cenk","Erdem","Ali","Mehmet","Ahmet"]
v = ["koşuyor","yüzüyor","zıplıyor","yatıyor","oturuyor"]
a = ["güzelce","hızla","yavaşça","telaşla","heyecanla"]
no = ["sandalye","kumsala","denize","dağa","yüzme havuzuna"]

x = random.choice(n)
y = random.choice(v)
z = random.choice(a)
w = random.choice(no)

print(f"{x} {w} {a} {v}")