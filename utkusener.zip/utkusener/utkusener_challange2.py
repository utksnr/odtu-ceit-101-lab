x = []

print("Commands: add:a, change:c, remove:r, show:s, quit:q")

while True:
    cmd = input("Enter command: ")

    if cmd == "a":
        y = input("Enter topping to add: ")
        if y in x:
            print(f"{y} is already in the pizza.")
        else:
            x.append(y)
            print(f"{y} added to the pizza.")
    
    elif cmd == "c":
        y = input("Enter topping to change: ")
        if y in x:
            z = input("Enter new topping: ")
            index = x.index(y)
            x[index] = z
            print(f"{y} changed to {z}.")
        else:
            print(f"{y} is not in the pizza.")

    elif cmd == "r":
        y = input("Enter topping to remove: ")
        if y in x:
            x.remove(y)
            print(f"{y} removed from the pizza.")
        else:
            print(f"{y} is not in the pizza.")

    elif cmd == "s":
        print(f"Current toppings:{x}")

    elif cmd == "q":
        print("Exiting the program.")
        break